#!/bin/bash

echo "🚀 Запуск Device Accounting локально..."
echo ""

cd "$(dirname "$0")"

# Проверка виртуального окружения
if [ ! -d "venv" ]; then
    echo "❌ Виртуальное окружение не найдено!"
    echo "Создайте его: python3 -m venv venv"
    exit 1
fi

# Активация виртуального окружения
source venv/bin/activate

# Проверка установленных пакетов
if ! python -c "import flask" 2>/dev/null; then
    echo "❌ Flask не установлен!"
    echo "Установите зависимости: pip install -r requirements.txt"
    exit 1
fi

# Проверка порта
if lsof -i :5001 &>/dev/null; then
    echo "⚠️  Порт 5001 уже занят!"
    echo "Остановите другой процесс или используйте другой порт"
    lsof -i :5001
    exit 1
fi

# Применение миграций
echo "🗄️  Применение миграций..."
export FLASK_APP=da.app
flask db upgrade

# Запуск сервера
echo ""
echo "▶️  Запуск сервера на http://127.0.0.1:5001"
echo "   Нажмите Ctrl+C для остановки"
echo ""

flask run --host=127.0.0.1 --port=5001 --debug

