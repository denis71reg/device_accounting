#!/usr/bin/expect -f
# Деплой через порт 2022

set timeout 120
set server "ittest@91.193.239.177"
set password "adXovByUUm6yJ88f"
set remote_path "/opt/device_accounting"

puts "🚀 Деплой через 91.193.239.177:2022"
puts ""

# Попытка подключения
puts "🔐 Проверка SSH подключения через порт 2022..."
spawn ssh -p 2022 -v -o StrictHostKeyChecking=no -o ConnectTimeout=30 $server "echo 'Connected'"

expect {
    "password:" {
        puts "✅ SSH доступен, требуется пароль"
        send "$password\r"
        exp_continue
    }
    "yes/no" {
        send "yes\r"
        exp_continue
    }
    timeout {
        puts "\n❌ SSH порт 2022 недоступен (таймаут)"
        puts ""
        puts "Возможные причины:"
        puts "  - Порт 2022 используется для веб-приложения, а не SSH"
        puts "  - Требуется VPN подключение"
        puts "  - SSH работает на другом порту"
        puts ""
        puts "💡 Альтернатива:"
        puts "  Выполните обновление на сервере вручную:"
        puts "  ssh ittest@192.168.16.44"
        puts "  cd /opt/device_accounting"
        puts "  docker-compose -f docker-compose.prod.yml down"
        puts "  docker-compose -f docker-compose.prod.yml build --no-cache"
        puts "  docker-compose -f docker-compose.prod.yml up -d"
        exit 1
    }
    eof
}

puts "\n✅ SSH подключение установлено"

# Загрузка файлов
puts "\n📦 Загрузка файлов..."
spawn rsync -avz -e "ssh -p 2022" --progress \
    --exclude '.git' --exclude 'venv' --exclude '__pycache__' \
    --exclude '*.pyc' --exclude 'instance' --exclude '.env' \
    --exclude '*.db' --exclude '*.log' --exclude '.DS_Store' \
    --exclude '*.tar.gz' \
    ./ $server:$remote_path/

expect {
    "password:" {
        send "$password\r"
        exp_continue
    }
    eof
}

puts "\n✅ Файлы загружены"

# Обновление
puts "\n🚀 Обновление на сервере..."
spawn ssh -p 2022 -o StrictHostKeyChecking=no $server

expect {
    "password:" {
        send "$password\r"
    }
    "yes/no" {
        send "yes\r"
        expect "password:"
        send "$password\r"
    }
}

expect "$ "
send "cd $remote_path\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml down\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml build --no-cache\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml up -d\r"
expect "$ "

send "sleep 5\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml ps\r"
expect "$ "

send "echo '✅ Готово!'\r"
expect "$ "

send "exit\r"
expect eof

puts "\n✅ Деплой завершен!"

