# Обновление на сервере

## Проблема
На сервере старая версия:
- ❌ В навигации "Инвентарь" вместо "Девайсы"
- ❌ Есть кнопки "Выдать" и "Вернуть" (должны быть удалены)
- ❌ Форма регистрации с одним полем "ФИО" вместо трех

## Решение: Обновление на сервере

### Шаг 1: Подключитесь к серверу
```bash
ssh ittest@192.168.16.44
# Пароль: adXovByUUm6yJ88f
```

### Шаг 2: Загрузите обновленные файлы

**Вариант A: Через rsync (с машины с доступом)**
```bash
rsync -avz --progress \
    --exclude '.git' --exclude 'venv' --exclude '__pycache__' \
    --exclude '*.pyc' --exclude 'instance' --exclude '.env' \
    --exclude '*.db' --exclude '*.log' \
    ./ ittest@192.168.16.44:/opt/device_accounting/
```

**Вариант B: Через архив**
```bash
# Загрузите update_package.tar.gz на сервер
scp update_package.tar.gz ittest@192.168.16.44:/opt/device_accounting/
```

### Шаг 3: На сервере выполните
```bash
cd /opt/device_accounting

# Если загрузили архив:
tar -xzf update_package.tar.gz

# Запустите обновление:
chmod +x update_server.sh
./update_server.sh
```

### Или вручную:
```bash
cd /opt/device_accounting

# Остановка
docker-compose -f docker-compose.prod.yml down

# Пересборка (без кэша)
docker-compose -f docker-compose.prod.yml build --no-cache

# Запуск
docker-compose -f docker-compose.prod.yml up -d

# Миграции
sleep 5
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade

# Проверка
docker-compose -f docker-compose.prod.yml ps
```

## Что должно измениться:

1. ✅ **Навигация**: "Инвентарь" → "Девайсы"
2. ✅ **Кнопки**: "Выдать" и "Вернуть" удалены
3. ✅ **Регистрация**: 3 поля (Имя, Фамилия, Отчество)

## После обновления проверьте:

- https://da.dev-ittest.ru - приложение работает
- В навигации есть "Девайсы" (не "Инвентарь")
- Нет кнопок "Выдать" и "Вернуть"
- Форма регистрации имеет 3 поля

