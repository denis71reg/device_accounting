#!/bin/bash
# Скрипт для выполнения на сервере после загрузки файлов

set -e

echo "🚀 Деплой Device Accounting на сервере..."

# Проверка наличия .env
if [ ! -f .env ]; then
    echo "⚠️  Файл .env не найден. Создаю из примера..."
    if [ -f env.example ]; then
        cp env.example .env
        echo "✏️  Пожалуйста, отредактируйте .env и установите SECRET_KEY"
        echo "   Сгенерировать ключ: python3 -c \"import secrets; print(secrets.token_hex(32))\""
        exit 1
    else
        echo "❌ Файл env.example не найден!"
        exit 1
    fi
fi

# Создание необходимых директорий
echo "📁 Создание директорий..."
mkdir -p instance logs
chmod 755 instance

# Остановка старых контейнеров
echo "🛑 Остановка старых контейнеров..."
docker-compose -f docker-compose.prod.yml down || true

# Сборка образа
echo "🔨 Сборка Docker образа..."
docker-compose -f docker-compose.prod.yml build

# Запуск приложения
echo "▶️  Запуск приложения..."
docker-compose -f docker-compose.prod.yml up -d

# Ожидание запуска
echo "⏳ Ожидание запуска приложения..."
sleep 5

# Применение миграций
echo "🗄️  Применение миграций базы данных..."
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade || echo "⚠️  Миграции уже применены или база данных не готова"

# Проверка статуса
echo "✅ Проверка статуса..."
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "✅ Деплой завершен!"
echo ""
echo "📝 Приложение доступно на: https://da.dev-ittest.ru"
echo ""
echo "📋 Просмотр логов:"
echo "   docker-compose -f docker-compose.prod.yml logs -f"
echo ""

