#!/bin/bash
# Финальный скрипт для деплоя на сервере
# Выполните НА СЕРВЕРЕ после подключения

set -e

echo "🚀 Обновление Device Accounting на сервере..."
echo ""

cd /opt/device_accounting

# Проверка .env
if [ ! -f .env ]; then
    echo "⚠️  .env не найден, создаю из примера..."
    [ -f env.example ] && cp env.example .env
fi

# Остановка
echo "🛑 Остановка контейнеров..."
docker-compose -f docker-compose.prod.yml down || true

# Пересборка БЕЗ кэша
echo "🔨 Пересборка образа (без кэша)..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Запуск
echo "▶️  Запуск приложения..."
docker-compose -f docker-compose.prod.yml up -d

# Ожидание
echo "⏳ Ожидание запуска..."
sleep 5

# Миграции
echo "🗄️  Применение миграций..."
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade || echo "⚠️  Миграции уже применены"

# Статус
echo "✅ Проверка статуса..."
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "✅ Обновление завершено!"
echo "📝 Проверьте: https://da.dev-ittest.ru"
echo "   Должно быть: 'Девайсы' вместо 'Инвентарь'"
echo "   Кнопки 'Выдать' и 'Вернуть' должны быть удалены"

