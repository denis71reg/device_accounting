# Инструкция по обновлению сервера

## Проблема
SSH недоступен с локальной машины. Нужно обновить сервер вручную.

## Решение

### Вариант 1: Через веб-консоль сервера
1. Загрузите `FINAL_DEPLOY.tar.gz` на сервер через веб-интерфейс
2. В консоли сервера выполните:
```bash
cd /opt/device_accounting
tar -xzf FINAL_DEPLOY.tar.gz
chmod +x DEPLOY_FINAL.sh
./DEPLOY_FINAL.sh
```

### Вариант 2: Через другую машину с доступом
```bash
scp FINAL_DEPLOY.tar.gz ittest@192.168.16.44:/opt/device_accounting/
ssh ittest@192.168.16.44
cd /opt/device_accounting
tar -xzf FINAL_DEPLOY.tar.gz
./DEPLOY_FINAL.sh
```

### Вариант 3: Вручную на сервере
```bash
cd /opt/device_accounting
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml build --no-cache
docker-compose -f docker-compose.prod.yml up -d
sleep 5
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade
```

## Что изменится:
- ✅ "Девайсы" вместо "Инвентарь"
- ✅ Кнопки "Выдать" и "Вернуть" удалены
- ✅ Форма регистрации: 3 поля

