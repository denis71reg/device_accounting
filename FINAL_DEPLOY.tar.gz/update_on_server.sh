#!/bin/bash
# Скрипт для выполнения НА СЕРВЕРЕ
# Скопируйте этот скрипт на сервер и запустите там

set -e

echo "🔄 Обновление Device Accounting на сервере..."
echo ""

cd /opt/device_accounting

# Проверка, что мы в правильной директории
if [ ! -f "docker-compose.prod.yml" ]; then
    echo "❌ Ошибка: docker-compose.prod.yml не найден"
    echo "Убедитесь, что вы находитесь в /opt/device_accounting"
    exit 1
fi

# Остановка старых контейнеров
echo "🛑 Остановка старых контейнеров..."
docker-compose -f docker-compose.prod.yml down || true

# Пересборка БЕЗ кэша (важно для обновления)
echo "🔨 Пересборка Docker образа (без кэша)..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Запуск обновленного приложения
echo "▶️  Запуск обновленного приложения..."
docker-compose -f docker-compose.prod.yml up -d

# Ожидание запуска
echo "⏳ Ожидание запуска приложения..."
sleep 5

# Применение миграций
echo "🗄️  Применение миграций базы данных..."
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade || echo "⚠️  Миграции уже применены"

# Проверка статуса
echo "✅ Проверка статуса..."
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "✅ Обновление завершено!"
echo ""
echo "📋 Проверьте изменения:"
echo "   - Откройте: https://da.dev-ittest.ru"
echo "   - В навигации должно быть 'Девайсы' (не 'Инвентарь')"
echo "   - Кнопки 'Выдать' и 'Вернуть' должны быть удалены"
echo "   - Форма регистрации должна иметь 3 поля"
echo ""

