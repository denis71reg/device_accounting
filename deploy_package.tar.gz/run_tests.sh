#!/bin/bash

set -e

echo "🧪 Запуск тестов Device Accounting..."

# Проверка виртуального окружения
if [ ! -d "venv" ]; then
    echo "❌ Виртуальное окружение не найдено. Создаю..."
    python3 -m venv venv
fi

# Активация виртуального окружения
source venv/bin/activate

# Установка зависимостей для тестирования
echo "📦 Установка зависимостей..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

# Запуск тестов
echo "🚀 Запуск тестов..."
pytest -v --tb=short --cov=da --cov-report=term-missing --cov-report=html

# Проверка результата
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Все тесты прошли успешно!"
    echo ""
    echo "📊 Отчет о покрытии кода: htmlcov/index.html"
    exit 0
else
    echo ""
    echo "❌ Некоторые тесты не прошли. Исправьте ошибки перед деплоем."
    exit 1
fi

