# Процесс обновления Device Accounting

## Варианты обновления

### 1. Полное обновление (рекомендуется для релизов)

Используется для обновлений с изменениями в зависимостях, Docker образе или структуре БД.

```bash
./update.sh
```

**Что делает:**
- Создает резервную копию базы данных
- Останавливает контейнеры
- Получает обновления из git (если используется)
- Пересобирает Docker образ
- Применяет миграции БД
- Запускает обновленное приложение
- Показывает логи

**Когда использовать:**
- Релиз новой версии
- Изменения в `requirements.txt`
- Изменения в `Dockerfile`
- Структурные изменения в БД

### 2. Быстрый хот-фикс (для срочных исправлений)

Используется для быстрого применения исправлений без пересборки образа.

```bash
./hotfix.sh
```

**Что делает:**
- Получает обновления из git
- Копирует код в работающий контейнер
- Перезапускает контейнер
- Применяет миграции (если есть)

**Когда использовать:**
- Исправление багов в коде
- Изменения в шаблонах
- Изменения в конфигурации (без зависимостей)
- Срочные исправления

**Ограничения:**
- Не работает при изменении зависимостей
- Не работает при изменении Dockerfile
- Может потребовать перезапуск вручную

## Ручное обновление

Если скрипты не подходят, можно обновить вручную:

```bash
# 1. Резервная копия БД
cp instance/devices.db instance/devices.db.backup-$(date +%Y%m%d-%H%M%S)

# 2. Получение обновлений
git pull

# 3. Остановка
docker-compose -f docker-compose.prod.yml down

# 4. Пересборка
docker-compose -f docker-compose.prod.yml build

# 5. Запуск
docker-compose -f docker-compose.prod.yml up -d

# 6. Миграции
docker-compose -f docker-compose.prod.yml exec app flask db upgrade

# 7. Проверка
docker-compose -f docker-compose.prod.yml logs -f
```

## Процесс обновления через Git

### Подготовка обновления

1. **Разработка и тестирование локально:**
   ```bash
   # Создайте ветку для фичи/фикса
   git checkout -b feature/new-feature
   
   # Разработайте и протестируйте
   # ...
   
   # Создайте миграции (если нужно)
   flask db migrate -m "описание изменений"
   
   # Закоммитьте изменения
   git add .
   git commit -m "Описание изменений"
   ```

2. **Слияние в main/master:**
   ```bash
   git checkout main
   git merge feature/new-feature
   git push origin main
   ```

### Применение на сервере

1. **Подключитесь к серверу:**
   ```bash
   ssh user@your-server
   cd /path/to/device_accounting
   ```

2. **Выберите метод обновления:**
   - Полное обновление: `./update.sh`
   - Хот-фикс: `./hotfix.sh`

3. **Проверьте работу:**
   ```bash
   # Проверьте логи
   docker-compose -f docker-compose.prod.yml logs -f
   
   # Проверьте статус
   docker-compose -f docker-compose.prod.yml ps
   
   # Проверьте доступность
   curl http://localhost:5001/
   ```

## Откат изменений

Если обновление вызвало проблемы:

### Откат к предыдущей версии

```bash
# 1. Остановите приложение
docker-compose -f docker-compose.prod.yml down

# 2. Откатите git
git checkout <previous-commit-hash>
# или
git reset --hard HEAD~1

# 3. Восстановите БД из резервной копии (если нужно)
cp instance/devices.db.backup-YYYYMMDD-HHMMSS instance/devices.db

# 4. Пересоберите и запустите
docker-compose -f docker-compose.prod.yml build
docker-compose -f docker-compose.prod.yml up -d

# 5. Откатите миграции (если нужно)
docker-compose -f docker-compose.prod.yml exec app flask db downgrade
```

### Откат только базы данных

```bash
# Остановите приложение
docker-compose -f docker-compose.prod.yml down

# Восстановите из резервной копии
cp instance/devices.db.backup-YYYYMMDD-HHMMSS instance/devices.db

# Запустите снова
docker-compose -f docker-compose.prod.yml up -d
```

## Автоматическое обновление (CI/CD)

### GitHub Actions (опционально)

Создайте `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to server
        uses: appleboy/ssh-action@master
        with:
          host: ${{ secrets.SERVER_HOST }}
          username: ${{ secrets.SERVER_USER }}
          key: ${{ secrets.SSH_KEY }}
          script: |
            cd /path/to/device_accounting
            ./update.sh
```

### Webhook обновление (опционально)

Можно настроить webhook на сервере для автоматического обновления при push в репозиторий.

## Чеклист перед обновлением

- [ ] Протестировано локально
- [ ] Созданы миграции (если нужно)
- [ ] Обновлен CHANGELOG
- [ ] Изменения закоммичены и запушены
- [ ] Создана резервная копия БД на сервере
- [ ] Выбран правильный метод обновления (update.sh или hotfix.sh)

## Мониторинг после обновления

После обновления проверьте:

1. **Логи приложения:**
   ```bash
   docker-compose -f docker-compose.prod.yml logs -f app
   ```

2. **Доступность:**
   ```bash
   curl -I http://localhost:5001/
   ```

3. **Функциональность:**
   - Вход в систему
   - Основные операции (создание, редактирование)
   - Проверка новых функций

4. **Производительность:**
   ```bash
   docker stats da_app_prod
   ```

## Часто задаваемые вопросы

**Q: Нужно ли останавливать приложение для обновления?**  
A: Да, для полного обновления нужно. Для хот-фикса контейнер перезапускается автоматически.

**Q: Что делать, если миграция не применилась?**  
A: Проверьте логи: `docker-compose -f docker-compose.prod.yml logs app`. При необходимости примените вручную: `docker-compose -f docker-compose.prod.yml exec app flask db upgrade`

**Q: Можно ли обновлять без простоя?**  
A: Для нулевого простоя нужна более сложная настройка (blue-green deployment). Для большинства случаев краткий перезапуск (30-60 сек) приемлем.

**Q: Как часто делать резервные копии?**  
A: Рекомендуется перед каждым обновлением. Также настройте автоматические ежедневные бэкапы.

## Поддержка

При проблемах с обновлением:
1. Проверьте логи: `docker-compose -f docker-compose.prod.yml logs`
2. Проверьте статус: `docker-compose -f docker-compose.prod.yml ps`
3. Откатитесь к предыдущей версии (см. раздел "Откат изменений")
4. Обратитесь в техподдержку IT Test


