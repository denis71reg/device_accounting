#!/bin/bash

set -e

echo "🔄 Обновление Device Accounting..."

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Проверка наличия .env
if [ ! -f .env ]; then
    echo -e "${RED}❌ Файл .env не найден!${NC}"
    exit 1
fi

# Создание резервной копии базы данных
echo "💾 Создание резервной копии базы данных..."
if [ -f instance/devices.db ]; then
    BACKUP_FILE="instance/devices.db.backup-$(date +%Y%m%d-%H%M%S)"
    cp instance/devices.db "$BACKUP_FILE"
    echo -e "${GREEN}✅ Резервная копия создана: $BACKUP_FILE${NC}"
else
    echo -e "${YELLOW}⚠️  База данных не найдена, пропускаю резервное копирование${NC}"
fi

# Остановка контейнеров
echo "🛑 Остановка контейнеров..."
docker-compose -f docker-compose.prod.yml down

# Получение обновлений (если используется git)
if [ -d .git ]; then
    echo "📥 Получение обновлений из git..."
    git pull || echo -e "${YELLOW}⚠️  Не удалось получить обновления из git${NC}"
fi

# Запуск тестов перед обновлением
echo "🧪 Запуск тестов перед обновлением..."
if [ -f "run_tests.sh" ]; then
    chmod +x run_tests.sh
    ./run_tests.sh
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Тесты не прошли. Обновление отменено.${NC}"
        exit 1
    fi
else
    echo -e "${YELLOW}⚠️  Скрипт run_tests.sh не найден. Пропускаю тесты.${NC}"
fi

# Пересборка образа
echo "🔨 Пересборка Docker образа..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Запуск контейнеров
echo "▶️  Запуск обновленного приложения..."
docker-compose -f docker-compose.prod.yml up -d

# Ожидание запуска
echo "⏳ Ожидание запуска приложения..."
sleep 5

# Применение миграций
echo "🗄️  Применение миграций базы данных..."
if docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade 2>/dev/null; then
    echo -e "${GREEN}✅ Миграции применены успешно${NC}"
else
    echo -e "${YELLOW}⚠️  Ошибка при применении миграций. Проверьте логи.${NC}"
fi

# Проверка статуса
echo "✅ Проверка статуса..."
if docker-compose -f docker-compose.prod.yml ps | grep -q "Up"; then
    echo -e "${GREEN}✅ Приложение успешно обновлено и запущено!${NC}"
else
    echo -e "${RED}❌ Ошибка при запуске приложения. Проверьте логи:${NC}"
    echo "   docker-compose -f docker-compose.prod.yml logs"
    exit 1
fi

# Показ логов
echo ""
echo "📋 Последние логи (Ctrl+C для выхода):"
echo ""
docker-compose -f docker-compose.prod.yml logs --tail=50 -f


