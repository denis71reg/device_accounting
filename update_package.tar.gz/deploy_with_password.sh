#!/usr/bin/expect -f
# Автоматический деплой с использованием пароля

set timeout 30
set server "ittest@192.168.16.44"
set password "adXovByUUm6yJ88f"
set remote_path "/opt/device_accounting"

puts "🚀 Автоматический деплой Device Accounting..."
puts "Сервер: $server"

# Загрузка файлов через rsync
puts "\n📦 Загрузка файлов на сервер..."
spawn rsync -avz --progress --exclude '.git' --exclude 'venv' --exclude '__pycache__' --exclude '*.pyc' --exclude 'instance' --exclude '.env' --exclude '*.db' --exclude '*.log' --exclude '.DS_Store' --exclude 'deploy_package.tar.gz' ./ $server:$remote_path/

expect {
    "password:" {
        send "$password\r"
        exp_continue
    }
    "yes/no" {
        send "yes\r"
        exp_continue
    }
    eof
}

# Выполнение деплоя на сервере
puts "\n🚀 Запуск деплоя на сервере..."
spawn ssh -o StrictHostKeyChecking=no $server

expect {
    "password:" {
        send "$password\r"
    }
    "yes/no" {
        send "yes\r"
        expect "password:"
        send "$password\r"
    }
}

expect "$ "
send "cd $remote_path\r"
expect "$ "

send "if [ ! -f .env ]; then if [ -f env.example ]; then cp env.example .env; echo '⚠️  ВАЖНО: Отредактируйте .env!'; fi; fi\r"
expect "$ "

send "mkdir -p instance logs && chmod 755 instance\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml down || true\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml build\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml up -d\r"
expect "$ "

send "sleep 5\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade || echo '⚠️  Миграции уже применены'\r"
expect "$ "

send "docker-compose -f docker-compose.prod.yml ps\r"
expect "$ "

send "echo '✅ Деплой завершен! Приложение доступно на: https://da.dev-ittest.ru'\r"
expect "$ "

send "exit\r"
expect eof

puts "\n✅ Автоматический деплой завершен!"

