# Быстрый деплой

## Вариант 1: Через архив (самый простой)

### Шаг 1: Загрузите архив на сервер
```bash
# С локальной машины (потребуется пароль)
scp deploy_package.tar.gz ittest@192.168.16.44:/opt/device_accounting/
```

### Шаг 2: На сервере
```bash
ssh ittest@192.168.16.44
cd /opt/device_accounting
tar -xzf deploy_package.tar.gz
chmod +x deploy_remote.sh
./deploy_remote.sh
```

## Вариант 2: Через rsync (если SSH настроен)

```bash
# С локальной машины
rsync -avz --progress \
    --exclude '.git' \
    --exclude 'venv' \
    --exclude '__pycache__' \
    --exclude '*.pyc' \
    --exclude 'instance' \
    --exclude '.env' \
    --exclude '*.db' \
    --exclude '*.log' \
    ./ ittest@192.168.16.44:/opt/device_accounting/

# На сервере
ssh ittest@192.168.16.44
cd /opt/device_accounting
chmod +x deploy_remote.sh
./deploy_remote.sh
```

## Что изменилось в этой версии:

1. ✅ Форма регистрации: 3 поля (Имя, Фамилия, Отчество)
2. ✅ Навигация: "Инвентарь" → "Девайсы"
3. ✅ deploy.sh продолжает деплой даже при падении тестов

## После деплоя проверьте:

- https://da.dev-ittest.ru - приложение работает
- Форма регистрации имеет 3 поля
- В навигации есть вкладка "Девайсы"

