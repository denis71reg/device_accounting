#!/bin/bash

set -e

echo "🚀 Развертывание Device Accounting..."

# Запуск тестов перед деплоем
echo "🧪 Запуск тестов перед развертыванием..."
if [ -f "run_tests.sh" ]; then
    chmod +x run_tests.sh
    ./run_tests.sh
    if [ $? -ne 0 ]; then
        echo "⚠️  Тесты не прошли полностью, но продолжаем развертывание..."
        echo "⚠️  Рекомендуется исправить тесты в ближайшее время."
    else
        echo "✅ Все тесты прошли успешно!"
    fi
else
    echo "⚠️  Скрипт run_tests.sh не найден. Пропускаю тесты."
fi

# Проверка наличия .env файла
if [ ! -f .env ]; then
    echo "⚠️  Файл .env не найден. Создаю из примера..."
    cp env.example .env
    echo "✏️  Пожалуйста, отредактируйте .env и установите SECRET_KEY"
    echo "   Сгенерировать ключ: python -c \"import secrets; print(secrets.token_hex(32))\""
    exit 1
fi

# Создание необходимых директорий
echo "📁 Создание директорий..."
mkdir -p instance logs
chmod 755 instance

# Сборка образа
echo "🔨 Сборка Docker образа..."
docker-compose -f docker-compose.prod.yml build

# Остановка старых контейнеров (если есть)
echo "🛑 Остановка старых контейнеров..."
docker-compose -f docker-compose.prod.yml down || true

# Запуск приложения
echo "▶️  Запуск приложения..."
docker-compose -f docker-compose.prod.yml up -d

# Ожидание запуска
echo "⏳ Ожидание запуска приложения..."
sleep 5

# Применение миграций
echo "🗄️  Применение миграций базы данных..."
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade || echo "⚠️  Миграции уже применены или база данных не готова"

# Проверка статуса
echo "✅ Проверка статуса..."
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "✅ Развертывание завершено!"
echo ""
echo "📝 Следующие шаги:"
echo "   1. Создайте первого супер-администратора:"
echo "      docker-compose -f docker-compose.prod.yml exec app flask create-superadmin email@ittest-team.ru \"ФИО\" --password"
echo ""
echo "   2. Просмотр логов:"
echo "      docker-compose -f docker-compose.prod.yml logs -f"
echo ""
echo "   3. Приложение доступно на: http://localhost:5001"
echo ""


