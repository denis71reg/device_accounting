#!/bin/bash
# Скрипт для обновления на сервере
# Запустите этот скрипт НА СЕРВЕРЕ после загрузки файлов

set -e

echo "🔄 Обновление Device Accounting на сервере..."

cd /opt/device_accounting

# Проверка .env
if [ ! -f .env ]; then
    echo "⚠️  Файл .env не найден. Создаю из примера..."
    if [ -f env.example ]; then
        cp env.example .env
        echo "✏️  ВАЖНО: Отредактируйте .env и установите SECRET_KEY!"
        exit 1
    fi
fi

# Создание директорий
echo "📁 Создание директорий..."
mkdir -p instance logs
chmod 755 instance

# Остановка старых контейнеров
echo "🛑 Остановка старых контейнеров..."
docker-compose -f docker-compose.prod.yml down || true

# Пересборка образа (без кэша для гарантии обновления)
echo "🔨 Пересборка Docker образа..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Запуск приложения
echo "▶️  Запуск обновленного приложения..."
docker-compose -f docker-compose.prod.yml up -d

# Ожидание запуска
echo "⏳ Ожидание запуска приложения..."
sleep 5

# Применение миграций
echo "🗄️  Применение миграций базы данных..."
docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade || echo "⚠️  Миграции уже применены"

# Проверка статуса
echo "✅ Проверка статуса..."
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "✅ Обновление завершено!"
echo "📝 Приложение доступно на: https://da.dev-ittest.ru"
echo ""
echo "📋 Проверьте изменения:"
echo "   - Вкладка 'Инвентарь' должна быть переименована в 'Девайсы'"
echo "   - Кнопки 'Выдать' и 'Вернуть' должны быть удалены"
echo "   - Форма регистрации должна иметь 3 поля (Имя, Фамилия, Отчество)"
echo ""

