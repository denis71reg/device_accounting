#!/bin/bash

set -e

echo "🔧 Исправление проблемы с сервером Device Accounting..."
echo ""

cd "$(dirname "$0")"

# Цвета
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 1. Проверка Docker
echo "1️⃣ Проверка Docker..."
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker не установлен!${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Docker установлен${NC}"

# 2. Остановка всех контейнеров
echo ""
echo "2️⃣ Остановка старых контейнеров..."
docker-compose -f docker-compose.prod.yml down 2>/dev/null || true
echo -e "${GREEN}✅ Контейнеры остановлены${NC}"

# 3. Проверка .env
echo ""
echo "3️⃣ Проверка конфигурации..."
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  Файл .env не найден, создаю из примера...${NC}"
    if [ -f env.example ]; then
        cp env.example .env
        echo -e "${YELLOW}⚠️  Пожалуйста, отредактируйте .env и установите SECRET_KEY${NC}"
    else
        echo -e "${RED}❌ Файл env.example не найден!${NC}"
        exit 1
    fi
fi
echo -e "${GREEN}✅ Конфигурация найдена${NC}"

# 4. Создание директорий
echo ""
echo "4️⃣ Создание необходимых директорий..."
mkdir -p instance logs
chmod 755 instance
chmod 755 logs
echo -e "${GREEN}✅ Директории созданы${NC}"

# 5. Пересборка образа
echo ""
echo "5️⃣ Пересборка Docker образа..."
docker-compose -f docker-compose.prod.yml build --no-cache
echo -e "${GREEN}✅ Образ пересобран${NC}"

# 6. Запуск контейнеров
echo ""
echo "6️⃣ Запуск контейнеров..."
docker-compose -f docker-compose.prod.yml up -d
echo -e "${GREEN}✅ Контейнеры запущены${NC}"

# 7. Ожидание запуска
echo ""
echo "7️⃣ Ожидание запуска приложения (15 секунд)..."
sleep 15

# 8. Проверка статуса
echo ""
echo "8️⃣ Проверка статуса контейнеров..."
if docker-compose -f docker-compose.prod.yml ps | grep -q "Up"; then
    echo -e "${GREEN}✅ Контейнеры запущены${NC}"
    docker-compose -f docker-compose.prod.yml ps
else
    echo -e "${RED}❌ Контейнеры не запущены!${NC}"
    echo ""
    echo "Логи последних ошибок:"
    docker-compose -f docker-compose.prod.yml logs app --tail=50
    exit 1
fi

# 9. Применение миграций
echo ""
echo "9️⃣ Применение миграций базы данных..."
if docker-compose -f docker-compose.prod.yml exec -T app flask db upgrade 2>/dev/null; then
    echo -e "${GREEN}✅ Миграции применены${NC}"
else
    echo -e "${YELLOW}⚠️  Ошибка при применении миграций (возможно, уже применены)${NC}"
fi

# 10. Проверка доступности
echo ""
echo "🔟 Проверка доступности приложения..."
sleep 5

if curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:5001 | grep -q "200\|302\|301"; then
    echo -e "${GREEN}✅ Приложение доступно на http://127.0.0.1:5001${NC}"
else
    echo -e "${YELLOW}⚠️  Приложение не отвечает на http://127.0.0.1:5001${NC}"
    echo ""
    echo "Последние логи:"
    docker-compose -f docker-compose.prod.yml logs app --tail=30
fi

# 11. Итоговая информация
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GREEN}✅ Процесс завершен!${NC}"
echo ""
echo "Полезные команды:"
echo "  • Просмотр логов: docker-compose -f docker-compose.prod.yml logs -f app"
echo "  • Статус: docker-compose -f docker-compose.prod.yml ps"
echo "  • Остановка: docker-compose -f docker-compose.prod.yml down"
echo "  • Перезапуск: docker-compose -f docker-compose.prod.yml restart"
echo ""
echo "Приложение должно быть доступно на:"
echo "  • http://127.0.0.1:5001 (напрямую)"
echo "  • http://127.0.0.1:2022 (через Nginx, если настроен)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

